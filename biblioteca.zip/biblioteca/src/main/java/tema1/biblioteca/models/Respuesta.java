package tema1.biblioteca.models;

import tema1.biblioteca.enums.Estado;

import java.util.Date;

public class Respuesta {
    private Estado estado;
    private String socio;
    private String libro;
    private Integer diasTotales;
    private Date fechaDevolucion;
    private String motivo;

    public Respuesta() {
    }

    public Respuesta(Estado estado, String motivo) {
        this.estado = estado;
        this.motivo = motivo;
    }

    public Respuesta(Estado estado, String socio, String libro, Integer diasTotales, Date fechaDevolucion) {
        this.estado = estado;
        this.socio = socio;
        this.libro = libro;
        this.diasTotales = diasTotales;
        this.fechaDevolucion = fechaDevolucion;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public String getSocio() {
        return socio;
    }

    public void setSocio(String socio) {
        this.socio = socio;
    }

    public String getLibro() {
        return libro;
    }

    public void setLibro(String libro) {
        this.libro = libro;
    }

    public Integer getDiasTotales() {
        return diasTotales;
    }

    public void setDiasTotales(Integer diasTotales) {
        this.diasTotales = diasTotales;
    }

    public Date getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(Date fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }
}
