package com.thymeleaf.thymeleaf.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ThymeleafController {

    @GetMapping("/elegir")
    public String elegir(@RequestParam(name = "idioma", required = false) String idioma) {
        if (idioma == "español"){
            return "redirect:/espanyol.html";
        }
        else if (idioma == "ingles") {
            return "redirect:/ingles.html";
        }
        else if (idioma == "aleman"){
            return "redirect:/aleman.html";
        }
        else if (idioma == "japones") {
            return "redirect:/japones.html";
        }
        return idioma;
    }
}
